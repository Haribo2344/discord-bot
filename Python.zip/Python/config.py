# 🔐 Configuration secrète pour le bot Discord
# Remplace les valeurs ci-dessous par les tiennes

APPLICATION_ID = 1370912081532162098  # <-- Remplace par ton Application ID (disponible sur Discord Developer Portal)
BOT_TOKEN = "MTM3MDkxMjA4MTUzMjE2MjA5OA.GY8tKE.FmPVTujvyeexGpdfDwylI6dt-Cd5HfOssHaTls"        # <-- Remplace par ton Token (garde-le privé !!)
